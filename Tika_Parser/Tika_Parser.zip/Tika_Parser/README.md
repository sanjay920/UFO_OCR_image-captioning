#UFO_Parser_ReadME
Ufo_parser extends the TXTParser and helps in parsing the information of the files in the folder to a much accessible format 

   •Jars Needed:
	1.Org.apache.tika.jar
	2.Org.apache.tika.parsers.jar
	3.Super-csv-2.0.1.jar
	4.Apache-commons.jar
	5.Commons-csv-1.4.jar
	6.Tika-core-1.3.jar

   •Steps to follow:
	1.Create two java classes: UfoClass and UfoParserClass
	2.Give the path to the british-ufo-files pdf folder. This script gives us the File name and the content of that file.
	3.It records all the filenames and the content of the respective files in the entire folder into a CSV file. 



