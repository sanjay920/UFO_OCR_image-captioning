package org.apache.tika.parser.none;

import java.io.IOException;
import java.util.ArrayList;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;

import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.xml.sax.SAXException;
import org.apache.tika.parser.ufoparser.UfoParserClass;
import org.apache.tika.sax.BodyContentHandler;
import org.apache.tika.parser.ParseContext;
//import org.apache.tika.parser.ner.corenlp.CoreNLPNERecogniser;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

public class UfoClass {
	
	public static final String FOLDER_NAME = "/Users/sachingb/Development/USC/CSCI_599/Assignments/HW2/OCR_Testing/";
	
	public static void main(String[] args) throws IOException,TikaException,SAXException {
		System.out.println("Inside main");
		UfoParserClass ufoparse = new UfoParserClass();
		File folder = new File(FOLDER_NAME);
		
		Metadata metadata = new Metadata();
		ParseContext pcontext = new ParseContext();
		BodyContentHandler handler = new BodyContentHandler();
		FileInputStream inputstream = new FileInputStream(new File("/Users/sachingb/Development/USC/CSCI_599/Assignments/HW2/OCR_Testing/out.txt"));
		
		ufoparse.parse(inputstream, handler, metadata, pcontext);
		String fileData = handler.toString();
		String[] pdf_folders = new String[8];
		pdf_folders[0] = "DEFE-24-1922";
		pdf_folders[1] = "DEFE-24-1923";
		pdf_folders[2] = "DEFE-24-1924";
		pdf_folders[3] = "DEFE-24-1925";
		pdf_folders[4] = "DEFE-31-172";
		pdf_folders[5] = "DEFE-31-173";
		pdf_folders[6] = "DEFE-31-174";
		pdf_folders[7] = "DEFE-31-175";
		
		
		CSVFormat csvFormat = CSVFormat.DEFAULT.withHeader("id", "text");
		CSVPrinter csvFilePrinter = new CSVPrinter(new FileWriter("/Users/sachingb/Development/USC/CSCI_599/Assignments/HW2/UFO_ocr_image-captioning_enrichment/british-ufo-files/records.csv"), csvFormat);
		
		try {
			for(String pdf_folder: pdf_folders) {
				processFolder("/Users/sachingb/Development/USC/CSCI_599/Assignments/HW2/UFO_ocr_image-captioning_enrichment/british-ufo-files/" + pdf_folder + "/outtxt", ufoparse, pdf_folder, csvFilePrinter);
			}
		} catch (Exception e) {
	        throw new RuntimeException(e.toString());
	    }
		csvFilePrinter.close();
		
	}
	
	public static void processFolder(String folderName, UfoParserClass ufoparse, String pdf_folder, CSVPrinter csvFilePrinter) throws IOException, TikaException, SAXException {
		File folder = new File(folderName);
		File[] listOfFiles = folder.listFiles();
		Metadata metadata = new Metadata();
		ParseContext pcontext = new ParseContext();
//		BodyContentHandler handler = new BodyContentHandler(-1);
		System.out.println("processing: " + pdf_folder);
		

		for(File f : listOfFiles) {
			if(f.exists()) {
				
				String rowName = f.getName().substring(0, f.getName().lastIndexOf('.'));
				BodyContentHandler handler = new BodyContentHandler();
				FileInputStream inputstream = new FileInputStream(f);
				ufoparse.parse(inputstream, handler, metadata, pcontext);
				String fileData = handler.toString();
				fileData = fileData.replaceAll("( +)"," ").trim();
				
				boolean description = fileData.matches("(?<=Description)\\s+");
				System.out.println(description);
				String row_id = pdf_folder + "_" + rowName;
				System.out.println("row id: " + row_id);
				
				ArrayList<Object> record = new ArrayList<Object>();
				record.add(row_id);
				record.add(fileData);
				csvFilePrinter.printRecord(record);

			}
		}
		
	}

}
