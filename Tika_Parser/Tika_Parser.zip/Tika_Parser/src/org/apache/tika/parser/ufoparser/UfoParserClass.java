package org.apache.tika.parser.ufoparser;

import java.io.IOException;
import java.io.InputStream;
import java.util.Set;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.sax.XHTMLContentHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.apache.tika.parser.txt.TXTParser;

public class UfoParserClass extends TXTParser {

	//@Override
	public Set<MediaType> getSupportedTypes(ParseContext arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void parse(InputStream arg0, ContentHandler arg1, Metadata arg2, ParseContext arg3)
			throws IOException, SAXException, TikaException {
		// TODO Auto-generated method stub
		super.parse(arg0, arg1, arg2, arg3);
		String fileContent = arg1.toString();
		String fileSubstring = "Too short";
//		System.out.println("UFO Parser class Filecontent is "+fileContent);
		if(fileContent.length() > 5) {
			fileSubstring = fileContent.substring(0, 5);
		}
//		System.out.println("Substring is "+fileSubstring);
		
		XHTMLContentHandler xhtml = new XHTMLContentHandler(arg1, arg2);
		xhtml.startDocument();
		xhtml.startElement("p");
		xhtml.characters(fileSubstring);
		xhtml.endElement("p");
		xhtml.endDocument();
		
//		super.parse(arg0, arg1, arg2, arg3);
//		System.out.println("HEllo there");
//		System.out.println(arg1.toString());
		
	}

}
